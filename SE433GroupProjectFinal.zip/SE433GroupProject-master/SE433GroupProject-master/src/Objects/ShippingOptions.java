package Objects;




public enum ShippingOptions {
    STANDARD,
    NEXTDAY
}
