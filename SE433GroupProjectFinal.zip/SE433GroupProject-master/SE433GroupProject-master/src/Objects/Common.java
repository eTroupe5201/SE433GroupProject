package Objects;



public class Common {
    public static final double TAX = .06;
    public static final int STD_COST =10;
    public static final int STD_DISCOUNT=50;
    public static final int NEXT_DAY=25;
    public static final int MIN_QUANTITY=1;
    public static final float MIN_PURCHASE=1f;
    public static final float MAX_PURCHASE=99999.99f;
 


}
